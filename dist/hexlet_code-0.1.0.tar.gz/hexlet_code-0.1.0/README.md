### Hexlet tests and linter status:
[![Actions Status](https://github.com/VadimYaskiv/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VadimYaskiv/python-project-49/actions)

# brain-even asciinema
https://asciinema.org/a/yytMX0rWYe862qeUfs5DGoOnJ

# brain-calc asciinema
https://asciinema.org/a/0765yYp6mL092OrvHlBBbo6TR

# brain-gcd asciinema
https://asciinema.org/a/4ARnhaUEiiWVQcrraBt0svJJx

# brain-progression asciinema
https://asciinema.org/a/xdDPedODB9im9qdrSVpAvoboZ

# brain-prime asciinema
https://asciinema.org/a/n0kc9IgRTbJ1Xi6lGyldhRLAq