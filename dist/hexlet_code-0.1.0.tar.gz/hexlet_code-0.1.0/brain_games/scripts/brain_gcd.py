from brain_games.greeting import greet
from brain_games.greeting import welcome_user
from brain_games.gcd_check import game

print('brain-gcd\n')


def main():
    greet()
    welcome_user()
    game()


if __name__ == '__main__':
    main()
