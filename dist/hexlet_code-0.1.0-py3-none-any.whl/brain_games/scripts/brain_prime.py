from brain_games.greeting import greet
from brain_games.greeting import welcome_user
from brain_games.prime_check import game

print('brain-prime\n')


def main():
    greet()
    welcome_user()
    game()


if __name__ == '__main__':
    main()
